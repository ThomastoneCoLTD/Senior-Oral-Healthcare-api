package com.kaii.dentix.domain.userServiceAgreement.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.kaii.dentix.domain.type.YnType;
import lombok.*;

import java.util.Date;

@Getter @Builder
@AllArgsConstructor @NoArgsConstructor
public class UserServiceAgreeList {

    private Long serviceAgreeId;

    private YnType isUserServiceAgree;

    private String serviceAgreeName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private Date date;

    public UserServiceAgreeList(Long serviceAgreeId, String serviceAgreeName, String isUserServiceAgree, Date date) {
        this.serviceAgreeId = serviceAgreeId;
        this.isUserServiceAgree = YnType.valueOf(isUserServiceAgree);
        this.serviceAgreeName = serviceAgreeName;
        this.date = date;
    }
}
